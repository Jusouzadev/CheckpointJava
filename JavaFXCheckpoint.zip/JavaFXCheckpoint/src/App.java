import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

public class App extends Application {

    private Window primaryStage;


    private void  mostrarContaDialog(Conta conta) {

        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("gui/layout.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            
            Stage dialogStage = new Stage();
        dialogStage.setTitle("Edita Conta");
        dialogStage.initModality(Modality.WINDOW_MODAL);
        dialogStage.initOwner(this.primaryStage);
        
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);
        
            MenuIniciar controller = loader.getController();
        controller.setDialogStage(dialogStage);
        controller.setConta(conta);
        
            dialogStage.showAndWait();
        
            return;
        
            } catch (IOException e) {
            e.printStackTrace();
            return;
        }
    }
    public static void main(String[] args) throws Exception {
        launch(args);
    }
        
    
    @Override
    public void start(Stage primaryStage) throws Exception {
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("layout.fxml"));
    Parent root = fxmlLoader.load();  
    Scene tela = new Scene(root); 
     

    primaryStage.setTitle("Controle de Finanças Pessoais");
    primaryStage.setScene(tela);
    primaryStage.show();



    }
}