import javafx.scene.control.TextField;

public class Conta {

    public Conta(TextField campoNome, TextField nomeConta, TextField dataVenc, TextField categoria) {
    }

}
