import javafx.beans.property.StringProperty;

public class Dados {

    private StringProperty nomeUsuario;
    private StringProperty nomeConta;
    private StringProperty dataVenc;
    private StringProperty categoria;


    public Dados(StringProperty nomeUsuario, StringProperty nomeConta, StringProperty dataVenc, StringProperty categoria){
    super();
    this.nomeUsuario = nomeUsuario;
    this.nomeConta = nomeConta;
    this.dataVenc = dataVenc;
    this.categoria = categoria;
}

public Dados(int i, String string, String string2, String string3, String string4) {
    }

public String getNomeUsuario(){
    return this.nomeUsuario.get();
}

public void setNomeUsuario(String nomeUsuario) {
    this.nomeUsuario.set(nomeUsuario);
}
   
public StringProperty nomeUsuarioProperty(){
    return this.nomeUsuario;
}

public String getNomeConta(){
    return this.nomeConta.get();
}

public void setNomeConta(String nomeConta) {
    this.nomeConta.set(nomeConta);
}
   
public StringProperty nomeContaProperty(){
    return this.nomeConta;
}
public String getDataVenc(){
    return this.dataVenc.get();
}

public void setDataVenc(String dataVenc) {
    this.dataVenc.set(dataVenc);
}
   
public StringProperty dataVencProperty(){
    return this.dataVenc;
}
public String getCategoria(){
    return this.categoria.get();
}

public void setCategoria(String categoria) {
    this.categoria.set(categoria);
}
   
public StringProperty categoriaProperty(){
    return this.categoria;
}
}