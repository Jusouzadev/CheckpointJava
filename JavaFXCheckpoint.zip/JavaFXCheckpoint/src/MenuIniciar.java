import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MenuIniciar {

    @FXML
    private Button botaoIniciar;

    @FXML
    private TextField campoNome;
    @FXML
    private TextField nomeConta;
    @FXML
    private TextField dataVenc;
    @FXML
    private ChoiceBox<String> categoria;
 
  
    /**
     * @param event
     */

    @FXML
    void iniciarPrograma(ActionEvent event) {
    
   
        System.out.println("Iniciou o programa");

        String nome = campoNome.getText();
        System.out.println("Nome de Usuario:" + nome);

        String conta = nomeConta.getText();
        System.out.println("Nome da Conta:" + conta);

        String vencimento = dataVenc.getText();
        System.out.println("Data de Vencimento:" + vencimento);

        Date data = null;
    	String dataTexto = new String("dd-MM-yyyy");
    	SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
    	try {
    		format.setLenient(false);
    		data = (Date) format.parse(dataTexto);
    	} catch (ParseException e) {
    		JOptionPane.showMessageDialog(null,"Digite a data em formato de dd/MM/yyyy","AVISO",JOptionPane.WARNING_MESSAGE);
    	}

        ObservableList<String> categ = categoria.getItems();
        System.out.println("Categoria:" + categ);
        
     
    }

public void setDialogStage(Stage dialogStage) {
}


public void setConta(Conta conta) {
}


public Object isOnClicked() {
    return null;
}



private Object carregarDados() {
    return null;
}

   // public void  {
       // ChoiceBox<String> choiceBoxCategoria;
      //  choiceBoxCategoria.getItems().addAll(List.of("LUZ", "ÁGUA", "ALUGUEL", "GÁS", "CARTÃO DE CRÉDITO"));
   
    }



